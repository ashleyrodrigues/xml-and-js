# Quiz 4

## Part 1

- open folder and run `npm install`
- run `npm run test` to see failing tests
- run `npm run main` to see it is failing
- implement functions in questions/ folder to make tests work (you can run `npm run q1`/`npm run q2`/... to run tests only for a single question)

## Part 2

- create 3 html pages:
  - html/vehicles.html - should have a table with all the vehicles loaded from the api
  - html/address.html - should have a table with all the addresses loaded from the api
  - html/users.html - sshould have a table with all the uses loaded from the api excluding address and vehicle fields
